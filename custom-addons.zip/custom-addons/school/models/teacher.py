
from odoo import models, fields, api ,exceptions

class Teacher(models.Model):
    _name='school.teacher'
    _description = 'School Teacher'
    name = fields.Char(required=True)
    phone=fields.Char(required=True)
    subject = fields.Selection([('english','English'),('arabic','Arabic'),('math','Math')],required=True)
