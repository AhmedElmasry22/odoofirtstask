
from odoo import models, fields, api ,exceptions
class Classes(models.Model):
    _name='school.classes'
    _description = 'School Classes'
    name = fields.Char(required=True)
    maximum_capacity = fields.Integer(string="Maximum Capacity",required=True)
    assign_teacher=fields.Many2one('school.teacher',ondelete='cascade',string="Teacher",required=True)
    student_ids=fields.Many2many('school.student',string="Students",required=True)

    @api.constrains('student_ids')
    def _check_registration_no(self):
        if (self.maximum_capacity < len(self.student_ids)):
            raise exceptions.ValidationError("Increase Maximum Capacity or remove excess Students")

    ''''
    @api.onchange('maximum_capacity', 'student_ids')
    def _verify_valid_seats(self):
        if (self.maximum_capacity < 0):
            return {
                "warning": {
                    'title': "Incorrect Maximum Capacity Value"
                    , 'message': "The Maximum Capacity Cant be Negetive"
                }
            }
        if (self.maximum_capacity > len(self.student_ids)):
            return {
                "warning": {
                    'title': "Too many Student",
                    'message': "Increase Maximum Capacity or remove excess Students"
                }
            }

        '''

