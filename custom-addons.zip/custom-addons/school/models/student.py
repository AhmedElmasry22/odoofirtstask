
from odoo import models, fields, api ,exceptions
from datetime import datetime
class Student(models.Model):
    _name='school.student'
    _description = 'School Student'
    name = fields.Char()
    date_of_birth = fields.Date(string="Date of Birth")
    address = fields.Char()
    phone=fields.Char(string="Phone")






