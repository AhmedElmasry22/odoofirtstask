from odoo import models, fields, api ,exceptions

class Examinations(models.Model):
    _name="school.examinations"
    _description = 'School Examinations'
    name = fields.Char(string='Exam Name', required=True)
    subject_cover = fields.Selection([('english','English'),('arabic','Arabic'),('math','Math')],string="Subject" ,required=True)
    maximum_marks = fields.Integer(string="Maximum Marks",required=True)
    #maximum_marks = fields.Integer(string="Maximum Marks")


